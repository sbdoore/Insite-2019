finalMatlabCode is the only folder you should use. Everything else is old code.
