import numpy as np
import cv2
import glob
import sys

CBOARDWIDTH = 7
CBOARDHEIGHT = 6
CBOARDSQUARE = 21.8 # millimeters

# termination criteria
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)

# prepare object points, like (0,0,0), (1,0,0), (2,0,0) ....,(6,5,0)
objp = np.zeros((CBOARDHEIGHT*CBOARDWIDTH,3), np.float32)
objp[:,:2] = np.mgrid[0:CBOARDWIDTH,0:CBOARDHEIGHT].T.reshape(-1,2)
for i in range(len(objp)):
    for j in range(len(objp[i])):
        objp[i][j] *= CBOARDSQUARE

print("objp: {}".format(objp))

# Arrays to store object points and image points from all the images.
objpoints = [] # 3d point in real world space
leftImgPoints = [] # 2d points in image plane.
rightImgPoints = [] # 2d points in image plane.
leftGray = []
rightGray = []
imgShape = None

leftImages = glob.glob('a*.jpg')
rightImages = glob.glob("b*.jpg")

count = 1
for i in range(len(leftImages)):
    print("count: {}".format(count))
    leftImg = cv2.imread(leftImages[i])
    rightImg = cv2.imread(rightImages[i])
    leftGray = cv2.cvtColor(leftImg,cv2.COLOR_BGR2GRAY)
    rightGray = cv2.cvtColor(rightImg,cv2.COLOR_BGR2GRAY)

    if count == 1:
        imgShape = tuple(reversed(leftImg.shape[:-1]))
        print("Img Shape {}".format(imgShape))
        cv2.imwrite('leftGray.png',leftGray)
        cv2.imwrite('rightGray.png',rightGray)

    # Find the chess board corners
    leftRet, leftCorners = cv2.findChessboardCorners(leftGray, (CBOARDWIDTH,CBOARDHEIGHT),None)
    rightRet, rightCorners = cv2.findChessboardCorners(rightGray, (CBOARDWIDTH,CBOARDHEIGHT),None)

    # If found, add object points, image points (after refining them)
    print("leftRet: {}".format(leftRet))
    print("rightRet: {}".format(rightRet))

    if not leftRet or not rightRet:
        print("Error with image pair #" + str(count))
        count += 1
        continue

    if leftRet == True:
        cv2.cornerSubPix(leftGray,leftCorners,(11,11),(-1,-1),criteria)
        leftImgPoints.append(leftCorners)

        # Draw and display the corners
        cv2.drawChessboardCorners(leftImg, (CBOARDWIDTH,CBOARDHEIGHT), leftCorners,leftRet)
        cv2.imshow('leftImg',leftImg)
        # cv2.waitKey(500) #was 500
        # cv2.imwrite('left drawn' + str(count) + '.png',leftImg)

    if rightRet == True:
        cv2.cornerSubPix(rightGray,rightCorners,(11,11),(-1,-1),criteria)
        rightImgPoints.append(rightCorners)

        # Draw and display the corners
        cv2.drawChessboardCorners(rightImg, (CBOARDWIDTH,CBOARDHEIGHT), rightCorners,rightRet)
        cv2.imshow('rightImg',rightImg)
        # cv2.waitKey(500) #was 500
        # cv2.imwrite('right drawn' + str(count) + '.png',rightImg)

    #append object points 
    objpoints.append(objp)

    count += 1



cv2.destroyAllWindows()
# print("Object Points: {} ".format(objpoints))

# exit(0)

leftRet, leftMatrix, leftDist, leftRotVec, leftTransVec = cv2.calibrateCamera(objpoints, leftImgPoints, imgShape,None,None)
rightRet, rightMatrix, rightDist, rightRotVec, rightTransVec = cv2.calibrateCamera(objpoints, rightImgPoints, imgShape,None,None)

# , file=open("calibresult.txt", "a")

# print("ret: {}".format(ret))
print("Left Matrix: {}".format(leftMatrix))
print("Right Matrix: {}".format(rightMatrix))
# print("dist: {}".format(dist))
# print("rvecs: {}".format(rvecs))
# print("tvecs: {}".format(tvecs))

###TEST PROJECTION ERROR####
mean_error = 0
for i in range(len(objpoints)):
    imgpoints2, _ = cv2.projectPoints(objpoints[i], leftRotVec[i], leftTransVec[i], leftMatrix, leftDist)
    error = cv2.norm(leftImgPoints[i],imgpoints2, cv2.NORM_L2)/len(imgpoints2)
    mean_error += error

print("Left total error: {}".format(mean_error/len(objpoints)))

mean_error = 0
for i in range(len(objpoints)):
    imgpoints2, _ = cv2.projectPoints(objpoints[i], rightRotVec[i], rightTransVec[i], rightMatrix, rightDist)
    error = cv2.norm(rightImgPoints[i],imgpoints2, cv2.NORM_L2)/len(imgpoints2)
    mean_error += error

print("Right total error: {}".format(mean_error/len(objpoints)))


print("Starting Stereo Calibration")

ret, leftMatrix, leftDist, rightMatrix, rightDist, r, t, e, f = cv2.stereoCalibrate(objpoints, leftImgPoints, rightImgPoints, leftMatrix, leftDist, rightMatrix, rightDist, imgShape)

# print("ret: {}".format(ret))
# print("Left Matrix: {}".format(leftMatrix))
# print("Left Dist: {}".format(leftDist))
# print("Right Matrix: {}".format(rightMatrix))
# print("right Dist: {}".format(rightDist))
# print("R: {}".format(r))
# print("T: {}".format(t))
# print("E: {}".format(e))
# print("F: {}".format(f))

rotLeft, rotRight, projLeft, projRight, dispMat, _, _ = cv2.stereoRectify(leftMatrix, leftDist, rightMatrix, rightDist, imgShape, r, t)

print("rotLeft: {}".format(rotLeft))
print("rotRight: {}".format(rotRight))
print("projLeft: {}".format(projLeft))
print("projRight: {}".format(projRight))
print("dispMat: {}".format(dispMat))

print("Left Image Point 0: {}".format(leftImgPoints[0]))
print("Right Image Point 0: {}".format(rightImgPoints[0]))

triangulatedPoints = cv2.triangulatePoints(projLeft, projRight, leftImgPoints[0], rightImgPoints[0])

print("Triangulated Points: {}".format(triangulatedPoints))


# 2.18cm for each chessboard square

