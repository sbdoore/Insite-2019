import cv2
import time
import os

a = cv2.VideoCapture(1)
b = cv2.VideoCapture(2)


capSize = (1280,960) # this is the size of my source video

# Define the codec and create VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'MJPG')
aOut = cv2.VideoWriter('aOutput.avi',fourcc, 20.0, (1280,960))
bOut = cv2.VideoWriter('bOutput.avi',fourcc, 20.0, (1280,960))


tEnd = time.time() + 10

while a.isOpened(): 
	aRet, aFrame = a.read()
	bRet, bFrame = b.read()
	if not aRet or not bRet:
		print("Failed to take video.")
		exit(-1)

	aOut.write(aFrame)
	bOut.write(bFrame)
	if time.time() > tEnd:
		a.release()
		b.release()
		aOut.release()
		bOut.release()
		print("Video Done being taken")
		exit(0)

print("All pictures taken. Starting camera calibration now")

# os.system("python3 calib2.py")

# print("Calibration finished.")



