import cv2
from time import sleep
import os

a = cv2.VideoCapture(1)
b = cv2.VideoCapture(2)
for i in range(5,0):
	print("Starting printing in " + str(i) + " seconds")
	sleep(1)


for i in range (30):
	sleep(2)
	print("Picture Taken")
	aRet, aImg = a.read()
	bRet, bImg = b.read()
	if not aRet or not bRet:
		print("Failed to take picture.")
		exit(-1)

	cv2.imwrite('aPic'+ str(i) + '.jpg', aImg)
	cv2.imwrite('bPic'+ str(i) + '.jpg', bImg)

print("All pictures taken. Starting camera calibration now")

# os.system("python3 calib2.py")

# print("Calibration finished.")



