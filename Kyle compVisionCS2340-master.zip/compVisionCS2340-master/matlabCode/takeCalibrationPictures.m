% Create the webcam object.Access the usb cameras
NUMPICS = 100;
curDir = pwd;
aFolder = strcat(pwd, '/a');
bFolder = strcat(pwd, '/b');
aPic = 'aPic';
bPic = 'bPic';
pictureExtension ='.png';

%Make the a folder if it does not exist already
if ~exist(aFolder, 'dir')
    mkdir(aFolder)
end

%Make the b folder if it does not exist already
if ~exist(bFolder, 'dir')
    mkdir(bFolder)
end

%Access the two webcams
cam1 = webcam(2);
cam2 = webcam(3);

%Iterate and take NUMPICS amount of pictures and write them to a and b.
for i = 1:NUMPICS
    charI = num2str(i);
    frameA = snapshot(cam1);
    frameB = snapshot(cam2);
    aPath = fullfile(aFolder, strcat(strcat(aPic, charI), pictureExtension));
    bPath = fullfile(bFolder, strcat(strcat(bPic, charI), pictureExtension));
    imwrite(frameA, aPath);
    imwrite(frameB, bPath);
    beep
    pause(1)
end

clear('cam1');
clear('cam2');
    