load('stereo.mat')
% You can use the calibration data to rectify stereo images.
%I2 = imread(imageFileNames2{1});


I1 = imread('/Users/loaner/Desktop/430/testImages/aTestImages/aPic8.png');
I2 = imread('/Users/loaner/Desktop/430/testImages/bTestImages/bPic8.png');


[I1, I2] = rectifyStereoImages(I1, I2, stereoParams);

I1 = undistortImage(I1, stereoParams.CameraParameters1);
I2 = undistortImage(I2, stereoParams.CameraParameters2);

faceDetector = vision.CascadeObjectDetector;
face1 = faceDetector(I1);
face2 = faceDetector(I2);

center1 = face1(1:2) + face1(3:4)/2;
center2 = face2(1:2) + face2(3:4)/2;

%imwrite(I1, 'aFarUndis.png')
%imwrite(I2, 'bFarUndis.png')

%I3 = imread('/Users/kmorriso/Desktop/428/closeCameras/aClose.png');
%I4 = imread('/Users/kmorriso/Desktop/428/closeCameras/bClose.png');

%I3 = undistortImage(I3, stereoParams.CameraParameters1);
%I4 = undistortImage(I4, stereoParams.CameraParameters2);

%imwrite(I3, 'aCloseUndis.png')
%imwrite(I4, 'bCloseUndis.png')


point3d = triangulate(center1, center2, stereoParams);
distanceInMeters = norm(point3d)/1000;
% 
distanceAsString = sprintf('first %0.2f meters', distanceInMeters)
I1 = insertObjectAnnotation(I1,'rectangle',face1,distanceAsString,'FontSize',18);
I2 = insertObjectAnnotation(I2,'rectangle',face2, distanceAsString,'FontSize',18);
I1 = insertShape(I1,'FilledRectangle',face1);
I2 = insertShape(I2,'FilledRectangle',face2);

imshowpair(I1, I2, 'montage');


% faceDetector = vision.CascadeObjectDetector;
% face3 = faceDetector(I3);
% face4 = faceDetector(I4);
% 
%center3 = face3(1:2) + face3(3:4)/2;
%center4 = face4(1:2) + face4(3:4)/2;


%center3 = [433 385];
%center4 = [439 242];
%center3 = [599 922];
%center4 = [604 767];

%center3 = [516 654; 433 385; 599 922];
%center4 = [522 505; 439 242; 604 767];


% point3d2 = triangulate(center3, center4, stereoParams);
% distanceInMeters2 = norm(point3d2)/1000;
% 
% distanceAsString2 = sprintf('second %0.2f meters', distanceInMeters2)
%I3 = insertObjectAnnotation(I3,'rectangle',face3,distanceAsString,'FontSize',18);
%I4 = insertObjectAnnotation(I4,'rectangle',face4, distanceAsString,'FontSize',18);
%I3 = insertShape(I3,'FilledRectangle',face3);
%I4 = insertShape(I4,'FilledRectangle',face4);
% 
% imshowpair(I3, I4, 'montage');





%[J1, J2] = ...
%   rectifyStereoImages(frameLeft, frameRight, stereoParams);



