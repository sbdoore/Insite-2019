load('stereo.mat')

% Create the webcam object.
%cam = webcam();

videoFileLeft = 'handshake_left.avi';
videoFileRight = 'handshake_right.avi';

readerLeft = vision.VideoFileReader(videoFileLeft, 'VideoOutputDataType', 'uint8');
readerRight = vision.VideoFileReader(videoFileRight, 'VideoOutputDataType', 'uint8');
player = vision.VideoPlayer('Position', [20,200,740 560]);

frameLeft = readerLeft.step();
frameRight = readerRight.step();

[frameLeftRect, frameRightRect] = ...
    rectifyStereoImages(frameLeft, frameRight, stereoParams);

% Create the people detector object. Limit the minimum object size for
% speed.
%peopleDetector = vision.PeopleDetector('MinSize', [166 83]);
peopleDetector = vision.PeopleDetector;

% Detect people.
bboxes = peopleDetector.step(frameLeftRect);
bboxesRight = peopleDetector.step(frameRightRect);

% Find the centroids of detected people.
centroidsLeft = [round(bboxes(:, 1) + bboxes(:, 3) / 2), ...
    round(bboxes(:, 2) + bboxes(:, 4) / 2)];
centroidsRight = [round(bboxesRight(:, 1) + bboxesRight(:, 3) / 2), ...
    round(bboxesRight(:, 2) + bboxesRight(:, 4) / 2)];