load('stereo.mat')

% Create the webcam object.Access the usb cameras
clear('cam1');
clear('cam2');
cam1 = webcam(2);
cam2 = webcam(3);

% Create TCP Client
%tcpAddress = '139.140.214.199';
%tcpPort = 9000;
%client = tcpclient(tcpAddress, tcpPort);

%To see live output
player = vision.VideoPlayer('Position', [20,200,740 560]);

%To save a video of the live output and features of that video
video = VideoWriter('videoCalibration.avi');
video.FrameRate = 1;
video.Quality = 100;
open(video);

XString = strcat('X:', {' '});
YString = strcat('Y:', {' '});
ZString = strcat('Z:', {' '});

%Set a counter and only process 8 frames for now
counter = 0;
while counter < 30 %Specify how many frames you want to capture.  
    frameLeft = snapshot(cam1);
    frameRight = snapshot(cam2);

    % Rectify the frames.
    [frameLeftRect, frameRightRect] = ...
        rectifyStereoImages(frameLeft, frameRight, stereoParams);
    
    
    % Detect people.
    %peopleDetector = vision.PeopleDetector('MinSize', [166 83]);
    peopleDetector = vision.PeopleDetector();
    bboxes = peopleDetector.step(frameLeftRect);
    bboxesRight = peopleDetector.step(frameRightRect);
    
    if ~(isempty(bboxes) || isempty(bboxesRight))
        % Find the centroids of detected people.
        centroidsLeft = [round(bboxes(:, 1) + bboxes(:, 3) / 2), ...
            round(bboxes(:, 2) + bboxes(:, 4) / 2)];
        centroidsRight = [round(bboxesRight(:, 1) + bboxesRight(:, 3) / 2), ...
            round(bboxesRight(:, 2) + bboxesRight(:, 4) / 2)];
        
        %Just get first detection for NOW
        centroidsLeft = centroidsLeft(1, :);
        centroidsRight = centroidsRight(1, :);
        point3d = triangulate(centroidsLeft, centroidsRight, stereoParams);
        point3d = round(point3d ./ 1000, 3);
        
        %xPoint = XString + num2str(point3d(1)) + " ";
        %yPoint = YString + num2str(point3d(2)) + " ";
        %zPoint = ZString + num2str(point3d(3)) + " ";
        
        xPoint = strcat(XString,strcat(num2str(point3d(1)), {'  '}));
        yPoint = strcat(YString,strcat(num2str(point3d(2)), {'  '}));
        zPoint = strcat(ZString,strcat(num2str(point3d(3))));
        %Convert point3d to meters. All coordinates are relative to the
        %camera one which should be the leftmost camera. Z is into the
        %page. X is right. Y is downward.
        distanceInMeters = norm(point3d);
        labels = strcat(xPoint,strcat(yPoint,zPoint));
        
        %Shows all found people but only label for first person found
        %This was just for debugging so in real implementation display all
        %labels.
        dispFrame = insertObjectAnnotation(frameLeftRect, 'rectangle', bboxes,...
            labels);
       
        matrixToSend = [point3d(1) point3d(3)] %X and Z are only important for museum
        %write(client, matrixToSend);
        
    else
        dispFrame = frameLeftRect;
    end
    
    % Display the frame.
    step(player, dispFrame);
    
    %For writing a video
    writeVideo(video, dispFrame);
    
    counter = counter + 1;
end
close(video);
clear('cam1');
clear('cam2');