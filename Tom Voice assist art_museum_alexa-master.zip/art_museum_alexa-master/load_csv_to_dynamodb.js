const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-east-1'});

exports.handler = (event, context) => {
    console.log(process.env.bucketName);
    const bucketName = process.env.bucketName;
    const keyName = process.env.keyName;
    const params = { Bucket: bucketName, Key: keyName };
    const csv=require('csvtojson');
    
    //grab the csv file from s3        
    const s3Stream = s3.getObject(params).createReadStream()

    csv().fromStream(s3Stream)
    .on('data', (row) => {
            //read each row 
            let jsonContent = JSON.parse(row);
            console.log(JSON.stringify(jsonContent));
             
            //push each row into DynamoDB
            let paramsToPush = {
                TableName:process.env.tableName,
		        Item:{
        		    "access_number":jsonContent.access_number,
        		    "object_type":jsonContent.object_type,
        		    "artist":jsonContent.artist,
        		    "title":jsonContent.title,
        		    "medium":jsonContent.medium,
        		    "dimensions":jsonContent.dimensions,
        		    "creation_date":jsonContent.creation_date,
        		    "description":jsonContent.description,
        		    "image_url":jsonContent.image_url,
        		    "credit_line":jsonContent.credit_line,
        		    "zone":jsonContent.zone
		        }
	        };
            addData(paramsToPush);
	});
      
};


function addData(params) {
    console.log("Adding a new item based on: ");
    docClient.put(params, function(err, data) {
            if (err) {
                console.error("Unable to add item. Error JSON:", JSON.stringify(err, null, 2));
            } else {
                console.log("Added item:", JSON.stringify(params.Item, null, 2));
	    }
	});
}
