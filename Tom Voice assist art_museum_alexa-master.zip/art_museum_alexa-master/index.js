/*
*   Authors: Tom Lucy, Sean Cork, Ben Hoxie
*   Date: 05/06/2019
*   
*   This file is the handler file for a custom Alexa skill to help visually-impaired individuals interact with one gallery
*   of the Bowdoin College Art Museum. Users can ask this skill for information at different levels of granularity, ranging
*   from an overview of the entire space to detailed descriptions of specific pieces of art.
*
*/

// Load the SDK for JavaScript
var AWS = require('aws-sdk');

// Create the DynamoDB service object
var docClient = new AWS.DynamoDB.DocumentClient();

// Name of the DynamoDB table, must be on the same AWS account
const tableName = "ArtGallery";

// variables in which to save the slot values globally
var artworkName = "";
var zoneName = "";

// array of objects - one for each zone, includes: name, description, and id value that corresponds to the zone attribute in the table
const zones = [
    {name: "italian wall", description: "The left half of this wall contains seventeenth century Italian paintings, which include religious and mythological scenes, scenes of everyday life, and one portrait. The centerpiece is a large unattributed painting titled Fish Shambles, which shows a scene of a fishmonger and a female customer. On the counter between them rests an impressive display of Mediterranean fish. Subjects in the other paintings include an enthroned Virgin Mary surrounded by adorers, Christ cleaning a temple full of animals, and Apollo chasing Daphne.", id: "4"},
    {name: "northern european wall", description: "The right half of this wall, including the central painting by Claes Cornelisz. Moeyaert of Joseph reuniting with his family, contains seventeenth century paintings from northern Europe, including Dutch, Flemish, and French works. The themes range from religious subjects, landscapes, and maritime scenes and the paintings depicting them are of a variety of sizes. Among these works is a copy of a Nicolas Poussin painting by British painter John Smibert depicting the Roman general Scipio returning the fiancée of the defeated Carthaginian ruler Allucius.", id: "5"},
    {name: "american portrait wall", description: "This wall contains early American portraits of those in the network of James Bowdoin III, including a charming double portrait of James as a boy with his sister, Elizabeth, on the left. Among the portraits, which date from the mid- to late eighteenth century, there is a mix of styles between those painters trained in the British tradition and those trained in the American tradition, though all of the known sitters depicted are American colonists. The centerpiece is a monumental painting of Brigadier General Samuel Waldo by American painter Robert Feke.", id: "6"},
    {name: "early renaissance wall", description: "This wall depicts early Renaissance works from northern Europe of a religious or devotional theme. Among the paintings, which date mostly to the late fifteenth and sixteenth centuries, there is a triptych altarpiece made after an original by Jan de Beer depicting the Nativity and a fifty-two-inch-tall wooden statue of the Virgin Mary and Christ. Other works include small devotional images of Christ and Mary Magdalene as well as an intricate scene of the destruction of Sodom and Gomorrah.", id: "1"},
    {name: "tomb of admiral jacob van wassenaer", description: "On this small wall is a Dutch painting of the tomb of Admiral Jacob Van Wassenaer in the Jacobskerk in Antwerp painted by Hendrik Cornelisz. Van Vliet. This painting can be thematically included with the early northern Renaissance and devotional paintings to its left. Though it is dated to the seventeenth century, it speaks in contrast to the other paintings, all of which date at least a century earlier. The bright white interior of the Jacobskerk represents the shift in ideology and aesthetic ushered in by the Reformation.", id: "2"},
    {name: "dorigny and saint peter", description: "On this small wall is a large painting of St. Peter being freed from Prison by an angel recently re-attributed to French painter Louis Dorigny, also called Ludovico Dorigny. This painting can be grouped in with the Italian paintings to its right, as Dorigny mainly lived and worked in Italy during the late seventeenth and early eighteenth centuries. The interaction of St. Peter and the angel match that of the duo of Apollo and Daphne seen to the right of this work.", id: "3"},
    {name: "the british eighteenth century wall", description: "This wall contains two British paintings from the end of the eighteenth century: a portrait and a large seascape. The portrait depicts a British admiral by the name of Charles Chivers and was painted by American painter John Singleton Copley during his time in England. The maritime scene, attributed to British painter Robert Freebairn, depicts a tempestuous storm with many small-scale figures fighting the wind along the shore.", id: "7"}
];

// Called when the user ends the session, not when a function ends the session
function onSessionEnded(sessionEndedRequest, session) {
    console.log(`onSessionEnded requestId=${sessionEndedRequest.requestId}, sessionId=${session.sessionId}`);
}

// --------------- Main handler -----------------------
// Route incoming requests by correct type. Calls correct functions for launch requests, any intents, and end requests.
exports.handler = (event, context, callback) => {
    try {
        console.log(`event.session.application.applicationId=${event.session.application.applicationId}`);
        
        // create new requestID if session is new
        if (event.session.new) {
            onSessionStarted({ requestId: event.request.requestId }, event.session);
        }
        
        // pass along a launch request
        if (event.request.type === 'LaunchRequest') {
            onLaunch(event.request,
                event.session,
                (sessionAttributes, speechletResponse) => {
                    callback(null, buildResponse(sessionAttributes, speechletResponse));
                });
        // pass along any intent request
        } else if (event.request.type === 'IntentRequest') {
            // globally record slot value if ArtworkIntent
            if (event.request.intent.name === 'ArtworkIntent') {
                artworkName = event.request.intent.slots.Artwork.value;
            // globally record slot value if ZoneIntent
            } else if (event.request.intent.name === 'ZoneIntent') {
                zoneName = event.request.intent.slots.Zone.value;
            }
            onIntent(event.request,
                event.session,
                (sessionAttributes, speechletResponse) => {
                    callback(null, buildResponse(sessionAttributes, speechletResponse));
                });
        // pass along an end request
        } else if (event.request.type === 'SessionEndedRequest') {
            onSessionEnded(event.request, event.session);
            callback();
        }
    } catch (err) {
        callback(err);
    }
};

// builds output JSON objects for interpretation by Alexa based on result of helper functions 
function buildSpeechletResponse(title, output, shouldEndSession) {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: output,
        },
        card: {
            type: 'Simple',
            title: `SessionSpeechlet - ${title}`,
            content: `SessionSpeechlet - ${output}`,
        },
        
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: "What can I help you with? Say 'Help' if you would like to hear the options again."
            },
        },
        
        shouldEndSession,
    };
}

function buildResponse(sessionAttributes, speechletResponse) {
    return {
        version: '1.0',
        sessionAttributes,
        response: speechletResponse,
    };
}
// ---------------

// --------------- Events -----------------------

// Called on a session started request, records id
function onSessionStarted(sessionStartedRequest, session) {
    console.log(`onSessionStarted requestId=${sessionStartedRequest.requestId}, sessionId=${session.sessionId}`);
}

// Called on a simple launch of the skill
function onLaunch(launchRequest, session, callback) {
    console.log(`onLaunch requestId=${launchRequest.requestId}, sessionId=${session.sessionId}`);
    // Dispatch to your skill's launch.
    getWelcomeResponse(callback);
}

// Switchboard for intents when user specifies one
function onIntent(intentRequest, session, callback) {
    console.log(`onIntent requestId=${intentRequest.requestId}, sessionId=${session.sessionId}`);
    const intent = intentRequest.intent;
    const intentName = intentRequest.intent.name;
    // Dispatch to your skill's intent handlers
    if (intentName === 'AMAZON.HelpIntent') {
        getHelpResponse(callback);
    } else if (intentName === 'AMAZON.StopIntent') {
        handleSessionEndRequest(callback);
    } else if (intentName === 'OverviewIntent') {
        getOverviewResponse(callback);
    } else if (intentName === 'ListZonesIntent') {
        getListOfZones(callback);
    } else if (intentName === 'ZoneIntent') {
        getZoneResponse(callback);
    } else if (intentName === 'ArtworkIntent') {
        getArtworkResponse(callback);
    } else if (intentName === 'SpatialArtworkIntent') {
        getArtworkResponseSpecialSpatial(callback);
    } else if (intentName === 'StylisticArtworkIntent') {
        getArtworkResponseSpecialStylistic(callback);
    }
}

// Create content for a welcome speechlet to be called on launch
function getWelcomeResponse(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Welcome";
    const speechOutput = "Welcome to the Bowdoin Gallery! If you would like an overview of the gallery, just say 'Please give me an overview" +
        " of the Bowdoin Gallery.' If you would like to learn about a specific section of the room, just say 'Please list the sections of the gallery.'" +
        " If you would like to learn about a specific piece of art, just say 'Please tell me about the artwork called' and then give the name" +
        " of the work of art. If you would like to hear the options again, just say 'Help' at any time";
    
    const shouldEndSession = false;
    callback(sessionAttributes,
        buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
    
}

// Create content for a help speechlet to be called if requested, provides user with their interaction options
function getHelpResponse(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Help";
    const speechOutput = "If you would like to hear an overview of the gallery, say the keyword overview. If you would like to hear the list of sections, say: List the sections. If you would like to hear about a particular section, say the keyword section followed by the name of the section. If you would like to hear about a specific piece of art, say the keyword artwork followed by the name of the piece.";

    const shouldEndSession = false;
    callback(sessionAttributes,
        buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
}

// Create content for an overview speechlet to be called if requested, gives the overview as found on the museum website
function getOverviewResponse(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Overview";
    const speechOutput = "The Museum’s collection of historic European and American art was shaped" +
    " by James Bowdoin III, the founder of the College, who bequeathed family collections of" +
    " European art in 1811. Subsequent generations have built on this legacy and collecting continues" +
    " to this day. This exhibition brings together works from Bowdoin’s collection with important" +
    " recent acquisitions that offer new perspectives on the art of Europe and the transatlantic" +
    " colonies.";
    
    const shouldEndSession = false;
    callback(sessionAttributes,
        buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
}

// Create content for a list of zones speechlet to be called if requested
function getListOfZones(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "List Zones";
    var speechOutput = "Here is a list of the sections in the gallery. ";
    
    for(var i = 0; i < zones.length; i++) {
        speechOutput += zones[i].name + ". ";
    }
    
    const shouldEndSession = false;
    callback(sessionAttributes,
        buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
}

// Create content for a zone speechlet about a specific zone, uses slot value to pull from zone description array and db table
function getZoneResponse(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Zone Response";
    const shouldEndSession = false;
    
    // grab values from array objects by slot value from user
    var description = zones.find(x => x.name === zoneName).description;
    var id = zones.find(x => x.name === zoneName).id;
    
    var speechOutput = "Here is a description for " + zoneName + ": " + description + " The " + zoneName + " section includes the following " +
    "works of art.";
    
    // parameters for scanning the table
    var params = {
        TableName: tableName,
        ExpressionAttributeNames: {
            "#ZO": "zone", 
            "#TI": "title"
        }, 
        ExpressionAttributeValues: {
            ":z": id
        }, 
        FilterExpression: "#ZO = :z", 
        ProjectionExpression: "#ZO, #TI", 
    };

    var results = [];
    
    // scan the db table, add results to the array and append to speechoutput
    docClient.scan(params, function(err, data) {
        if (err) {
           console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
           speechOutput = "There was an error, please try again.";
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        } else {
            console.log("Query succeeded.");
            data.Items.forEach(function(item) {
                results.push(item.title);
            });
            for (var i = 0; i < results.length; ++i) {
                speechOutput += " " + results[i] + ".";
            }
            callback(sessionAttributes,
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        }
    });
    
}

// Create content for an artwork speechlet about a specific piece, uses slot value to scan db table
function getArtworkResponse(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Piece";
    const shouldEndSession = false;
    var speechOutput = "";
    
    var params = {
        TableName: tableName,
        ExpressionAttributeNames: {
            "#DE": "description"
        }, 
        ExpressionAttributeValues: {
            ":a": artworkName
        }, 
        FilterExpression: "title = :a", 
        ProjectionExpression: "#DE", 
    };
    
    // scan the db table, append description to the speechoutput
    docClient.scan(params, function(err, data) {
        if (err) {
           console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
           speechOutput = "There was an error, please try again.";
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        } else {
            console.log("Query succeeded.");
            console.log(data.Items);
            speechOutput = data.Items[0].description;
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        }
    });
    
}



// Create content for an artwork spatial description speechlet about the special piece from UX/UI (Apollo and Daphne)
function getArtworkResponseSpecialSpatial(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Piece";
    const shouldEndSession = false;
    var speechOutput = "";
    
    var params = {
        TableName: tableName,
        ExpressionAttributeNames: {
            "#DE": "spatial_description"
        }, 
        ExpressionAttributeValues: {
            ":a": "Apollo and Daphne"
        }, 
        FilterExpression: "title = :a", 
        ProjectionExpression: "#DE", 
    };
    
    docClient.scan(params, function(err, data) {
        if (err) {
           console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
           speechOutput = "There was an error, please try again.";
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        } else {
            console.log("Query succeeded.");
            speechOutput = data.Items[0].spatial_description;
            speechOutput += " If you would like a stylistic description, request one using the keyword: stylistic description."
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        }
    });
    
}

// Create content for an artwork stylistic description speechlet about the special piece from UX/UI (Apollo and Daphne)
function getArtworkResponseSpecialStylistic(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Piece";
    const shouldEndSession = false;
    var speechOutput = "";
    
    var params = {
        TableName: tableName,
        ExpressionAttributeNames: {
            "#DE": "stylistic_description"
        }, 
        ExpressionAttributeValues: {
            ":a": "Apollo and Daphne"
        }, 
        FilterExpression: "title = :a", 
        ProjectionExpression: "#DE", 
    };
    
    docClient.scan(params, function(err, data) {
        if (err) {
           console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
           speechOutput = "There was an error, please try again.";
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        } else {
            console.log("Query succeeded.");
            speechOutput = data.Items[0].stylistic_description;
            speechOutput += " If you would like a spatial description of this piece, request one by giving the keyword: spatial description."
            callback(sessionAttributes, 
                buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
        }
    });
    
}

// Provides an exit message when the skill is done
function handleSessionEndRequest(callback) {
    
    const sessionAttributes = {};
    const cardTitle = "Session Ended";
    const speechOutput = "Thank you for visiting the Bowdoin Gallery!";

    const shouldEndSession = true;
    callback(sessionAttributes, 
        buildSpeechletResponse(cardTitle, speechOutput, shouldEndSession));
}
